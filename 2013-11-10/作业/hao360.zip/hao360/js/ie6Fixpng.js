// JavaScript Document
  DD_belatedPNG.fix('div');
  DD_belatedPNG.fix('button');
  DD_belatedPNG.fix('a');
  DD_belatedPNG.fix('h1');
  DD_belatedPNG.fix('h5');
  DD_belatedPNG.fix('form');
  DD_belatedPNG.fix('p img');
  DD_belatedPNG.fix('a img');
  DD_belatedPNG.fix('img');
  DD_belatedPNG.fix('input');
  DD_belatedPNG.fix('li');
  DD_belatedPNG.fix('td');
  DD_belatedPNG.fix('span');
  DD_belatedPNG.fix('table tr td');
